import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateAddreessComponent } from './update-addreess.component';

describe('UpdateAddreessComponent', () => {
  let component: UpdateAddreessComponent;
  let fixture: ComponentFixture<UpdateAddreessComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateAddreessComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateAddreessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
