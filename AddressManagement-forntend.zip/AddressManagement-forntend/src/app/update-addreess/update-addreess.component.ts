import { Component, OnInit } from '@angular/core';
import { Address } from '../address';
import { AddressserviceService } from '../addressservice.service';


@Component({
  selector: 'app-update-addreess',
  templateUrl: './update-addreess.component.html',
  styleUrls: ['./update-addreess.component.css']
})
export class UpdateAddreessComponent implements OnInit {
  edit:Address = new Address();

  constructor(private addressservice:AddressserviceService) { }

  ngOnInit() {
  }

 

  public updateInfo():void
  {
    
    this.addressservice.update(this.edit).subscribe(data=>{
      alert("address updated");


    
    },
    error=>
    {
     
      alert("AddressId not found");
      console.log("error occured ",error);
      
    }
    );
  }
}
