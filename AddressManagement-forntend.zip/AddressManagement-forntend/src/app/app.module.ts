import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {FormsModule} from '@angular/forms';

import { AppComponent } from './app.component';
import { ViewAddressComponent } from './view-address/view-address.component';
import { AddAddressComponent } from './add-address/add-address.component';
import { DeleteAddressComponent } from './delete-address/delete-address.component';
import { UpdateAddreessComponent } from './update-addreess/update-addreess.component';
import { HttpClientModule } from '@angular/common/http';

const appRoutes:Routes=[
  {path:'',component:ViewAddressComponent},
  {path:'updateAddress',component:UpdateAddreessComponent},
  {path:'addAddress',component:AddAddressComponent},
  

  {path:'**',redirectTo:'',pathMatch:'full'}
]

@NgModule({
  declarations: [
    AppComponent,
    ViewAddressComponent,
    AddAddressComponent,
    DeleteAddressComponent,
    UpdateAddreessComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
