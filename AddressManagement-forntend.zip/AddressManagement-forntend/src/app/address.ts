export class Address {
    AddressId:Number
    city:String
    state:String
    zip:String
    buildingNo:String
    feild:String
    UserId:Number
}

