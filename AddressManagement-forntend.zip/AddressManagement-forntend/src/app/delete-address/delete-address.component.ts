import { Component, OnInit } from '@angular/core';
import { AddressserviceService } from '../addressservice.service';

@Component({
  selector: 'app-delete-address',
  templateUrl: './delete-address.component.html',
  styleUrls: ['./delete-address.component.css']
})
export class DeleteAddressComponent implements OnInit {

  constructor(private addressservice:AddressserviceService) { }

  ngOnInit() {
  }
  

}
