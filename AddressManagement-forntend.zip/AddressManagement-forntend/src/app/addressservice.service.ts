import { Injectable } from '@angular/core';
import {Address} from './address'
import {HttpClient, HttpClientModule} from '@angular/common/http'
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AddressserviceService {
  address: Address[]=[];

  constructor(private http:HttpClient) { }

  loaddate():Observable<any>
  {
    let  url = "http://localhost:1137/address";

    return this.http.get(url);
  }

  createNewAddress(address:Address):Observable<any>
  {
    let url="http://localhost:1137/address/add";

    return this.http.post(url,address,{responseType:'text'});
  }

  delete(addressId:number):Observable<any>
  {
      let url="http://localhost:1137/address/delete/"
      return this.http.delete(url+addressId);
  }

  update(address:Address):Observable<any>
  {
    let end=address.AddressId;
    
    let url = "http://localhost:1137/address/update/";
    return this.http.put(url+end,address,{responseType:'text'});
  }
}
