import { Component, OnInit } from '@angular/core';
import { Address } from '../address';
import { AddressserviceService } from '../addressservice.service';

@Component({
  selector: 'app-add-address',
  templateUrl: './add-address.component.html',
  styleUrls: ['./add-address.component.css']
})
export class AddAddressComponent implements OnInit {

  add:Address = new Address();

  constructor(private addressservice:AddressserviceService) { }

  ngOnInit():void {
  }
  public addAddress():void
  {
    this.addressservice.createNewAddress(this.add).subscribe(data=>{
      alert("Address added"+this.add.city);


    
    },
    error=>
    {
      console.log("error occured ",error);
    }
    );
  }
}