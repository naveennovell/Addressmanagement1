import { Component, OnInit } from '@angular/core';
import { AddressserviceService } from '../addressservice.service';
import { Address } from '../address';


@Component({
  selector: 'app-view-address',
  templateUrl: './view-address.component.html',
  styleUrls: ['./view-address.component.css']
})
export class ViewAddressComponent implements OnInit {

  editflag:boolean=false;

  constructor(private addressservice:AddressserviceService) {}
   address:Address[]=[];
   edit:Address=new Address();

   ngOnInit(): void {
    this.addressservice.loaddate().subscribe(data=>
    {this.address=data;
  },
  error=>
  {
    console.log("error occured ",error);
  }
    );


   
  }
  deleteAddress(addressId: number) {
    this.addressservice.delete(addressId).subscribe(data=> {
      alert("address deleted");
     
    },

     error =>
     {
      console.log("error occured",error);
     });
    }
    
    }